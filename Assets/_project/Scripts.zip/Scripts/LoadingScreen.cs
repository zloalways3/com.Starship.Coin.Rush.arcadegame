﻿using ZeroSDK.UIBuilder.Core.UIElements;

namespace _project.Scripts
{
    public sealed class LoadingScreen : ScreenView
    {
        
    }
}
